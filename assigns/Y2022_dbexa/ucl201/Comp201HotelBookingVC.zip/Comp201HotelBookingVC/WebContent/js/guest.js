/**
 *   Code to allow manipulation of guest date on back end server 
 */


var Guest={};   // singleton instance
    if (!Guest.instance) {
    	Guest.instance={};
    	
    	function moneyFormat(money) {
    		var ret="";
    		var cash=money.value;
    		
    		ret=ret+cash % 100;
    		if (ret.length==1) ret="0"+ret;
    		ret=Math.floor(cash/100)+"."+ret;
    		if (money.currencyCode=="GBP") {
    			ret="£"+ret;
    		}
    		if (money.currencyCode=="USD") {
    			ret="$"+ret;
    		}
    		if (money.currencyCode=="EUR") {
    			ret="€"+ret;
    		}
    		
    		return(ret);
    	}
    	
    	Command.apply(Guest.instance); // Inherits from command
    	
    	Guest.instance.guestChange=function() {
    		var selectedId=$('#guestChooser').val();
    		Guest.instance.getGuestList(selectedId);	// each time the guest changes update the list and bookings
    	}
    	
    	Guest.instance.bookingChange=function() {
    		var parameters=new Array();
        	
    		parameters["objectType"]="Booking";
    		
    		var bookingId=$("#bookingChooser").val();
    		parameters["bookingId"]=bookingId;    	
    		parameters["guestId"]=$("#guestChooser").val();    	
    		
    		this.onSendRequest("getObjectList",parameters,function(response) {
    			Guest.instance.updateBooking(response.responseData.roomBookings);
    		});
    	}
    	
    	Guest.instance.formatDate=function(localDateObject) {
    		return(""+localDateObject.date.day+"/"+localDateObject.date.month+"/"+localDateObject.date.year);
    	}

    	Guest.instance.deleteRoomBooking=function(roomBookingId) {
    		var parameters=new Array();
    		parameters["startDate"]=$("#datepickerStartBooking").val();
        	parameters["endDate"]=$("#datepickerEndBooking").val();
        	
        	parameters["roomBookingId"]=roomBookingId;		    		
        	this.onSendRequest("deleteRoomBooking",parameters,function(response) {
        		if (response.responseData.roomBookings) {
    				Guest.instance.updateBooking(response.responseData.roomBookings);
    			}
        		var roomList=response.responseData.rooms;
        		if (roomList) {
    	    	   Guest.instance.updateRoomChooser(roomList)
        		}
    		
        	});	
    	}

    	Guest.instance.checkInRoomBooking=function(roomBookingId) {
    		var parameters=new Array();
    		parameters["roomBookingId"]=roomBookingId;		    		
        	this.onSendRequest("checkInRoomBooking",parameters,function(response) {
        		if (response.responseData.roomBookings) {
    				Guest.instance.updateBooking(response.responseData.roomBookings);
    			}
        	});	
    	}

    	
    	Guest.instance.addRoomBooking=function() {
    		var roomId=$("#roomChooser").val();
    		var parameters=new Array();
        	parameters["startDate"]=$("#datepickerStartBooking").val();
        	parameters["endDate"]=$("#datepickerEndBooking").val();
        	parameters["roomId"]=roomId;
        	parameters["bookingId"]=$('#bookingChooser').val();
        	
        	this.onSendRequest("addRoomBooking",parameters,function(response) {  
        				if (response.responseData.roomBookings) {
        					Guest.instance.updateBooking(response.responseData.roomBookings);	
        				}
        		Guest.instance.updateRoomChooser(response.responseData.rooms); // update room list as well
        		
        	});
        	
    		
    	}
    	
    	Guest.instance.formatSimpleDate = function(date) {
    		var retValue="";
    		if (date.getDate()<10) {
    			retValue+="0";
    		} 
    		retValue+=date.getDate();
    		retValue+="-";
    		if (date.getMonth()+1<10) {
    			retValue+="0";
    		} 
    		retValue+=(date.getMonth()+1);    		
    		retValue+="-";
    		retValue+=date.getFullYear();
    	    return(retValue);
    	}
    	
    	Guest.instance.findRoomsStart=function() {
    		$("#datepickerEndBooking").prop('disabled', false); // enable the other picker
    		// We now set the end date picker to be only allowed after the start one
    		//alert("Data picked is "+$("#datepickerStartBooking").datepicker("getDate"));
    		var min=$("#datepickerStartBooking").datepicker("getDate");
    		min.setDate(min.getDate() + 1);
    		$( "#datepickerEndBooking" ).datepicker( "option", "minDate",min);
    		$( "#datepickerEndBooking" ).datepicker( "option", "defaultDate",min );
    		$( "#datepickerEndBooking" ).val(Guest.instance.formatSimpleDate(min));
    		Guest.instance.findRooms();
    	}
    	
    	Guest.instance.findRoomsEnd=function() {
    		
    		Guest.instance.findRooms();
    	}

    	Guest.instance.updateRoomChooser=function(roomList) {
    		if (roomList.length>0) {
    		    $("#addRoomButton").prop('disabled', false); // room's available to book
    		} else {
    			$("#addRoomButton").prop('disabled', true); // not possible list is empty
    		}
    		$('#roomChooser').find('option').remove().end();
		      for (var idx=0;idx<roomList.length;idx++) {
			      var room=roomList[idx];
			      var o = new Option("Room "+room.roomNumber+" "+room.roomDescription.description,room.roomId);
			/// jquerify the DOM object 'o' so we can use the html method
			      $(o).html("Room "+room.roomNumber+" "+room.roomDescription.description,room.roomId);
			      $("#roomChooser").append(o);
		   }
    	}

    	
    	Guest.instance.findRooms=function() {
        	var parameters=new Array();
        	parameters["startDate"]=$("#datepickerStartBooking").val();
        	parameters["endDate"]=$("#datepickerEndBooking").val();
        		
        	this.onSendRequest("getavailable",parameters,function(response) {  
        		// We now fill the rooms into the room picker
        		
        		var roomList=response.responseData.rooms;
        	    	Guest.instance.updateRoomChooser(roomList)
        		
        		
        		
        	});
    	}

    	
    	Guest.instance.updateBooking =function(roomBookings) {
    		var table = document.getElementById("roomBookings");	
    		var rowCount = table.rows.length;
    		for(var i=1; i<rowCount; i++) {
				table.deleteRow(1);
    		}
    		if (!roomBookings) return;
    		for (var idx=0;idx<roomBookings.length;idx++) {
    			var roomBooking=roomBookings[idx];
    			var row=table.insertRow(1);
    			var newcell	= row.insertCell(0);
    			if (roomBooking.checkedIn) {    				
        			   newcell.innerHTML = '<input  type="button" id="checkinRoomBooking" value="Check In" disabled onclick="Guest.instance.checkInRoomBooking('+roomBooking.roomBookingId+')"></input>';    			
     			} else {
     			   newcell.innerHTML = '<input  type="button" id="checkinRoomBooking" value="Check In"  onclick="Guest.instance.checkInRoomBooking('+roomBooking.roomBookingId+')"></input>';    			
     			}
    			newcell	= row.insertCell(0);
    			
    			if (roomBooking.checkedIn) {    				
       			   newcell.innerHTML = '<input  type="button" id="deleteRoomBooking" value="Delete Room Booking" disabled onclick="Guest.instance.deleteRoomBooking('+roomBooking.roomBookingId+')"></input>';    			
    			} else {
    				newcell.innerHTML = '<input  type="button" id="deleteRoomBooking" value="Delete Room Booking" onclick="Guest.instance.deleteRoomBooking('+roomBooking.roomBookingId+')"></input>';    				
    			}
    			newcell	= row.insertCell(0);
    			
    			newcell.innerHTML = Guest.instance.formatDate(roomBooking.endDate);
    			newcell	= row.insertCell(0);
    			newcell.innerHTML = Guest.instance.formatDate(roomBooking.startDate);
    			newcell	= row.insertCell(0);
    			newcell.innerHTML = moneyFormat(roomBooking.room.roomDescription.tarrif);
    			newcell	= row.insertCell(0);
    			newcell.innerHTML =roomBooking.room.roomDescription.maxOccupancy;
    			newcell	= row.insertCell(0);
    			newcell.innerHTML=roomBooking.room.roomDescription.description;
    			newcell	= row.insertCell(0);
    			if (roomBooking.checkedIn) {
    				newcell.innerHTML = roomBooking.room.roomNumber+" (checked in)";
    			} else {
    			   newcell.innerHTML = roomBooking.room.roomNumber;
    			}
    			
    		}
    	}
    	
    	Guest.instance.getGuestList=function(selectedId) {
    		var parameters=new Array();
    		if (!selectedId) {			// no quest selected so choose all of them
    			selectedId=0;
    		}
    		parameters["objectType"]="Guest";
    		parameters["guestId"]=selectedId;    		    		
    		this.onSendRequest("getObjectList",parameters,function(response) {
    			//alert("Response is "+JSON.stringify(response));
    			if (response.responseData.data) {	// guest list update
    			$('#guestChooser').find('option').remove().end();
    			for (var idx=0;idx<response.responseData.data.length;idx++) {
    				var item=response.responseData.data[idx];
    				var o = new Option(item.forename1+" "+item.surname,item.personID);
    				/// jquerify the DOM object 'o' so we can use the html method
    				$(o).html(item.forename1+" "+item.surname);
    				$("#guestChooser").append(o);
    			}
    			}
    			$('#bookingChooser').find('option').remove().end();
    			if (response.responseData.bookings) {
    				if (response.responseData.bookings.length==0) { // no booking's so can't add room
     					$("#addRoomButton").prop('disabled', true); // cannot book room's if not possible    		    		    				    
    				} else {
    					if ($("#roomChooser").children('option').length) {
    						$("#addRoomButton").prop('disabled',false); // found rooms available
    					}
    				}
    			}
    			var bookingId=0;
    			for (var idx=0;idx<response.responseData.bookings.length;idx++) {
    				
    				var item=response.responseData.bookings[idx];
    				//alert("id is "+item.bookingId);
    				if (bookingId==0) {
    					bookingId=item.bookingId;
    				}
    				var o = new Option("Booking "+item.bookingId+" "+item.dateOfBooking,item.bookingId);
    				/// jquerify the DOM object 'o' so we can use the html method
    				$(o).html("Booking "+item.bookingId+" "+item.dateOfBooking);
    				$("#bookingChooser").append(o);
    				$("#bookingChooser").val(item.bookingId);
    			}
    			$('#bookingChooser').val(bookingId);
    			Reception.instance.showPanel('panelBookings');
    			if (selectedId>0) {
    				$('#guestChooser').val(selectedId);
    				
    			}
    			Guest.instance.updateBooking(response.responseData.roomBookings);
    			
    		});
    	}
    	Guest.instance.addBooking=function() {
    		var parameters=new Array();            
    		var selectedGuest = $("#guestChooser").children("option:selected").val();
    		parameters["guestID"]=selectedGuest;
    		this.onSendRequest("addBooking",parameters,function(response) {
    			if (response.responseData.data) {
    				if ($("#roomChooser").children('option').length) {
						$("#addRoomButton").prop('disabled',false); // found rooms available
					}
    			   var item=response.responseData.data;
    			   var o = new Option("Booking "+item.bookingId+" "+item.dateOfBooking,item.bookingId);
   				/// jquerify the DOM object 'o' so we can use the html method
   				   $(o).html("Booking "+item.bookingId+" "+item.dateOfBooking);
   				   $("#bookingChooser").append(o);
   				   $("#bookingChooser").val(item.bookingId);
    			}    			
    		});
    	}
    	Guest.instance.addGuest=function() {
    		var parameters=new Array();            
    		$('#panelAddGuest').children('input').each(function () {
    			parameters[this.id]=this.value;		// copy into parameters    	           
    		});
    		this.onSendRequest("addGuest",parameters,function(response) {
                $('#panelAddGuest').children('div').each(function () {
    				this.innerHTML=" ";
    			});
                $("#response").html(translateText(response.responseMessage));    
        		if (response.responseData.data) { // check if error messages present
        			$('#panelAddGuest').children('div').each(function () {
        				for (const [field,message] of Object.entries(response.responseData.data)) { 
        			    	if (this.id==field+"Error") {
        						this.innerHTML=message;	// set the message for the filed
        						
        					}
        	    					
        				  
        				}
        			});
    	    		
        		}
        	});	
    		
    			
    	}
    	
    }
